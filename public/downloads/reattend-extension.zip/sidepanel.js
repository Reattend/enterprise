const searchInput = document.getElementById("search-input");
const searchBtn = document.getElementById("search-btn");
const content = document.getElementById("content");
const emptyState = document.getElementById("empty-state");
const tabAsk = document.getElementById("tab-ask");
const tabResume = document.getElementById("tab-resume");

let currentTab = "ask";

// ── Tab switching ─────────────────────────────────────────────────────

[tabAsk, tabResume].forEach((btn) => {
  btn.addEventListener("click", () => {
    currentTab = btn.dataset.tab;
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");

    if (currentTab === "resume") loadResume();
    else showEmpty();
  });
});

// ── Search / Ask ──────────────────────────────────────────────────────

searchBtn.addEventListener("click", doSearch);
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") doSearch();
});

async function doSearch() {
  const query = searchInput.value.trim();
  if (!query) return;

  searchBtn.disabled = true;
  searchBtn.textContent = "...";
  content.innerHTML = '<div class="loading">Thinking...</div>';

  // Ask and search in parallel
  const [askRes, searchRes] = await Promise.all([
    sendMessage({ type: "ask_memory", question: query }),
    sendMessage({ type: "search_memories", query }),
  ]);

  let html = "";

  // Handle quota exceeded
  if (askRes?.error === "quota_exceeded") {
    html += `
      <div class="quota-card">
        <p>You've used ${askRes.used ?? 0}/${askRes.limit ?? 20} AI queries today.<br/>Upgrade to Pro for unlimited queries.</p>
        <a href="https://reattend.com/app/billing" target="_blank">Upgrade to Pro</a>
      </div>
    `;
  } else if (askRes?.ok && askRes.answer) {
    // Show AI answer
    html += `
      <div class="answer-card">
        <div class="answer-label">Answer</div>
        <div class="answer-text">${renderMarkdown(askRes.answer)}</div>
      </div>
    `;
  }

  // Show search results
  const results = searchRes?.results || [];
  if (results.length > 0) {
    html += '<div class="section-heading">Related memories</div>';
    results.forEach((r) => {
      html += renderMemoryCard(r);
    });
  }

  if (!html) {
    html = '<div class="empty-state"><p>No memories found for that query.<br/>Keep browsing and Reattend will learn.</p></div>';
  }

  content.innerHTML = html;
  searchBtn.disabled = false;
  searchBtn.textContent = "Ask";
}

// ── Resume my day ─────────────────────────────────────────────────────

async function loadResume() {
  content.innerHTML = '<div class="loading">Preparing your day...</div>';

  const res = await sendMessage({ type: "ask_memory", question: "Summarize what I was working on recently. What are my pending tasks and next steps? Be specific with names, dates, and action items." });

  if (res?.ok && res.answer) {
    const points = res.answer.split(/\n/).filter((l) => l.trim().length > 0);

    let html = `
      <div class="resume-card">
        <div class="resume-title">Resume my day</div>
        ${points.map((p) => `
          <div class="resume-item">
            <div class="resume-dot"></div>
            <div class="resume-text">${renderMarkdown(p.replace(/^[-•*]\s*/, ''))}</div>
          </div>
        `).join("")}
      </div>
    `;

    // Also load recent for context
    const recent = await sendMessage({ type: "get_recent_memories" });
    const records = recent?.records || [];
    if (records.length > 0) {
      html += '<div class="section-heading">Recent memories</div>';
      html += records.slice(0, 5).map(renderMemoryCard).join("");
    }

    content.innerHTML = html;
  } else {
    content.innerHTML = '<div class="empty-state"><p>Start your day — memories will build up as you work.<br/>Try spending a few minutes on Slack, email, or docs.</p></div>';
  }
}

// ── Helpers ────────────────────────────────────────────────────────────

function renderMemoryCard(r) {
  const type = r.record_type || r.type || "context";
  const title = r.title || "Untitled";
  const summary = r.summary || "";
  const time = r.created_at || r.createdAt || "";
  const timeStr = time ? formatTime(time) : "";

  return `
    <div class="memory-card" onclick="window.open('https://reattend.com/app/memories/${r.id}', '_blank')">
      <div class="memory-title">${escapeHtml(title)}</div>
      ${summary ? `<div class="memory-summary">${escapeHtml(summary.slice(0, 120))}</div>` : ""}
      <div class="memory-meta">
        <span class="memory-tag ${type}">${type}</span>
        ${timeStr ? `<span class="memory-time">${timeStr}</span>` : ""}
      </div>
    </div>
  `;
}

function formatTime(dateStr) {
  try {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    return new Date(dateStr).toLocaleDateString();
  } catch {
    return "";
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function renderMarkdown(str) {
  return escapeHtml(str)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/\[(\d+)\]/g, '<span class="citation">[$1]</span>')
    .replace(/^[-•]\s+(.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br/>')
    .replace(/^/, '<p>').replace(/$/, '</p>')
}

function showEmpty() {
  content.innerHTML = `
    <div class="empty-state">
      <div class="empty-icon">🧠</div>
      <p>Ask a question about your memories,<br/>or switch to "My day" for a briefing.</p>
    </div>
  `;
}

function sendMessage(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => {
      resolve(response || { ok: false });
    });
  });
}

// Focus search on load
searchInput.focus();
