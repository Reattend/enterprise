// Content script for extracting meaningful content from web apps

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "extract_content") {
    const content = extractContent();
    sendResponse(content);
  }
  return true;
});

function extractContent() {
  const host = window.location.hostname;

  if (host === "mail.google.com") return extractGmail();
  if (host.includes("slack.com")) return extractSlack();
  if (host.includes("atlassian.net")) return extractJira();
  if (host.includes("linear.app")) return extractLinear();
  if (host === "docs.google.com") return extractGoogleDocs();
  if (host.includes("notion.so") || host.includes("notion.site")) return extractNotion();

  // Fallback: extract visible text
  return extractGeneric();
}

// ── Gmail ─────────────────────────────────────────────────────────────

function extractGmail() {
  // Try to get the open email content
  const emailBody = document.querySelector('[data-message-id] .a3s, .ii.gt .a3s');
  if (emailBody) {
    const subject = document.querySelector('h2.hP')?.textContent?.trim() || '';
    const sender = document.querySelector('.gD')?.getAttribute('email') ||
                   document.querySelector('.gD')?.textContent?.trim() || '';
    const body = emailBody.textContent?.trim() || '';

    if (body.length > 20) {
      return {
        app: "Gmail",
        content: `Email from: ${sender}\nSubject: ${subject}\n\n${body.slice(0, 3000)}`,
      };
    }
  }

  // Try thread view — get the last few messages
  const messages = document.querySelectorAll('.adn.ads');
  if (messages.length > 0) {
    const subject = document.querySelector('h2.hP')?.textContent?.trim() || '';
    const thread = [];
    messages.forEach((msg, i) => {
      if (i >= 3) return; // Last 3 messages
      const sender = msg.querySelector('.gD')?.textContent?.trim() || '';
      const body = msg.querySelector('.a3s')?.textContent?.trim() || '';
      if (body) thread.push(`${sender}: ${body.slice(0, 500)}`);
    });

    if (thread.length > 0) {
      return {
        app: "Gmail",
        content: `Email thread: ${subject}\n\n${thread.join('\n\n')}`,
      };
    }
  }

  return { app: "Gmail", content: "" };
}

// ── Slack ──────────────────────────────────────────────────────────────

function extractSlack() {
  // Get channel name
  const channel = document.querySelector('[data-qa="channel_name"]')?.textContent?.trim() ||
                  document.querySelector('.p-channel_sidebar__name__text')?.textContent?.trim() || '';

  // Get recent messages
  const messages = document.querySelectorAll('[data-qa="virtual-list-item"], .c-message_kit__blocks');
  const extracted = [];

  messages.forEach((msg, i) => {
    if (i >= 10) return; // Last 10 messages
    const sender = msg.querySelector('[data-qa="message_sender_name"], .c-message__sender')?.textContent?.trim() || '';
    const text = msg.querySelector('[data-qa="message-text"], .c-message_kit__text')?.textContent?.trim() || '';
    if (text && text.length > 5) {
      extracted.push(`${sender}: ${text.slice(0, 300)}`);
    }
  });

  if (extracted.length > 0) {
    return {
      app: "Slack",
      content: `Slack #${channel}\n\n${extracted.join('\n')}`,
    };
  }

  return { app: "Slack", content: "" };
}

// ── Jira / Atlassian ──────────────────────────────────────────────────

function extractJira() {
  // Try ticket view
  const title = document.querySelector('[data-testid="issue.views.issue-base.foundation.summary.heading"]')?.textContent?.trim() ||
                document.querySelector('#summary-val')?.textContent?.trim() || '';
  const description = document.querySelector('[data-testid="issue.views.field.rich-text.description"]')?.textContent?.trim() ||
                      document.querySelector('#description-val')?.textContent?.trim() || '';
  const status = document.querySelector('[data-testid="issue.views.issue-base.foundation.status.status-field-wrapper"]')?.textContent?.trim() || '';
  const assignee = document.querySelector('[data-testid="issue.views.field.user.assignee"]')?.textContent?.trim() || '';

  // Get comments
  const comments = [];
  document.querySelectorAll('[data-testid="issue.activity.comments-list"] [data-testid*="comment"]').forEach((c, i) => {
    if (i >= 5) return;
    const author = c.querySelector('[data-testid*="author"]')?.textContent?.trim() || '';
    const text = c.querySelector('[data-testid*="body"]')?.textContent?.trim() || '';
    if (text) comments.push(`${author}: ${text.slice(0, 300)}`);
  });

  if (title) {
    let content = `Jira: ${title}`;
    if (status) content += `\nStatus: ${status}`;
    if (assignee) content += `\nAssignee: ${assignee}`;
    if (description) content += `\n\n${description.slice(0, 1500)}`;
    if (comments.length > 0) content += `\n\nComments:\n${comments.join('\n')}`;
    return { app: "Jira", content };
  }

  return { app: "Jira", content: "" };
}

// ── Linear ────────────────────────────────────────────────────────────

function extractLinear() {
  const title = document.querySelector('[data-testid="issue-title"], .issue-title')?.textContent?.trim() ||
                document.querySelector('h1')?.textContent?.trim() || '';
  const description = document.querySelector('[data-testid="issue-description"], .ProseMirror')?.textContent?.trim() || '';
  const status = document.querySelector('[data-testid="issue-status"]')?.textContent?.trim() || '';

  if (title) {
    let content = `Linear: ${title}`;
    if (status) content += `\nStatus: ${status}`;
    if (description) content += `\n\n${description.slice(0, 1500)}`;
    return { app: "Linear", content };
  }

  return { app: "Linear", content: "" };
}

// ── Google Docs ───────────────────────────────────────────────────────

function extractGoogleDocs() {
  const title = document.querySelector('.docs-title-input')?.value ||
                document.querySelector('.docs-title-widget')?.textContent?.trim() || '';
  const body = document.querySelector('.kix-appview-editor')?.textContent?.trim() || '';

  if (body.length > 30) {
    return {
      app: "Google Docs",
      content: `Document: ${title}\n\n${body.slice(0, 3000)}`,
    };
  }

  return { app: "Google Docs", content: "" };
}

// ── Notion ────────────────────────────────────────────────────────────

function extractNotion() {
  const title = document.querySelector('.notion-page-block .notranslate, [placeholder="Untitled"]')?.textContent?.trim() || '';
  const blocks = document.querySelectorAll('.notion-page-content [data-block-id] .notranslate');
  const text = [];
  blocks.forEach((b, i) => {
    if (i >= 30) return;
    const t = b.textContent?.trim();
    if (t) text.push(t);
  });

  if (text.length > 0) {
    return {
      app: "Notion",
      content: `Notion: ${title}\n\n${text.join('\n')}`.slice(0, 3000),
    };
  }

  return { app: "Notion", content: "" };
}

// ��─ Generic fallback ──────────────────────────────────────────────────

function extractGeneric() {
  const title = document.title || '';
  const article = document.querySelector('article, [role="main"], main, .content, #content');
  const text = article?.textContent?.trim() || document.body.textContent?.trim() || '';

  if (text.length > 50) {
    return {
      app: "Web",
      content: `${title}\n\n${text.slice(0, 3000)}`,
    };
  }

  return { app: "Web", content: "" };
}
