const API_BASE = "https://reattend.com";

const connectView = document.getElementById("connect-view");
const connectedView = document.getElementById("connected-view");
const tokenInput = document.getElementById("token-input");
const connectBtn = document.getElementById("connect-btn");
const disconnectBtn = document.getElementById("disconnect-btn");
const errorEl = document.getElementById("error");

// Account display
const avatarInitial = document.getElementById("avatar-initial");
const accountName = document.getElementById("account-name");
const accountEmail = document.getElementById("account-email");
const accountToken = document.getElementById("account-token");

// Paste transcript elements
const pasteInput = document.getElementById("paste-input");
const pasteBtn = document.getElementById("paste-btn");
const savedBanner = document.getElementById("saved-banner");

// ── Init ──────────────────────────────────────────────────────────────

chrome.storage.local.get(["reattend_token", "reattend_email", "reattend_name"], (stored) => {
  if (stored.reattend_token) {
    showConnected(stored.reattend_token, stored.reattend_email || null, stored.reattend_name || null);
  } else {
    showConnect();
  }
});

// ── Connect button ─────────────────────────────────────────────────────

connectBtn.addEventListener("click", async () => {
  const token = tokenInput.value.trim();
  if (!token) {
    showError("Please paste your token");
    return;
  }

  connectBtn.disabled = true;
  connectBtn.textContent = "Connecting...";
  errorEl.classList.add("hidden");

  try {
    const res = await fetch(`${API_BASE}/api/tray/proxy/usage`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      showError("Invalid token. Go to Settings → API Tokens to get one.");
      connectBtn.disabled = false;
      connectBtn.textContent = "Connect";
      return;
    }

    // Fetch user info
    let email = null;
    let name = null;
    try {
      const meRes = await fetch(`${API_BASE}/api/tray/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (meRes.ok) {
        const me = await meRes.json();
        email = me.email || null;
        name = me.name || null;
      }
    } catch {}

    chrome.storage.local.set({ reattend_token: token, reattend_email: email, reattend_name: name }, () => {
      chrome.runtime.sendMessage({ type: "save_token", token });
      showConnected(token, email, name);
    });
  } catch {
    showError("Connection failed. Check your internet.");
    connectBtn.disabled = false;
    connectBtn.textContent = "Connect";
  }
});

// ── Open sidebar button ───────────────────────────────────────────────

document.getElementById("open-sidebar-btn")?.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "open_sidepanel" });
  window.close();
});

// ── Disconnect button ─────────────────────────────────────────────────

disconnectBtn.addEventListener("click", () => {
  chrome.storage.local.remove(["reattend_token", "reattend_email", "reattend_name"]);
  chrome.runtime.sendMessage({ type: "clear_token" });
  showConnect();
});

// ── Enter key on token input ──────────────────────────────────────────

tokenInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") connectBtn.click();
});

// ── Paste transcript ──────────────────────────────────────────────────

pasteInput.addEventListener("input", () => {
  pasteBtn.disabled = pasteInput.value.trim().length < 10;
});

pasteBtn.addEventListener("click", async () => {
  const text = pasteInput.value.trim();
  if (text.length < 10) return;

  pasteBtn.disabled = true;
  pasteBtn.textContent = "Saving...";
  savedBanner.classList.add("hidden");
  errorEl.classList.add("hidden");

  try {
    const token = await new Promise(resolve => {
      chrome.storage.local.get(["reattend_token"], s => resolve(s.reattend_token));
    });

    const res = await fetch(`${API_BASE}/api/tray/capture`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        text,
        source: "extension_paste",
        metadata: { capture_type: "manual_paste" },
      }),
    });

    if (!res.ok) throw new Error("Failed to save");
    const data = await res.json();

    if (data.status === "deduped") {
      showError("This content was already saved.");
    } else {
      savedBanner.classList.remove("hidden");
      pasteInput.value = "";
      setTimeout(() => savedBanner.classList.add("hidden"), 5000);
    }
  } catch (err) {
    showError("Could not save. Check your connection.");
  } finally {
    pasteBtn.disabled = pasteInput.value.trim().length < 10;
    pasteBtn.textContent = "Save to Reattend";
  }
});

// ── View helpers ──────────────────────────────────────────────────────

function showConnect() {
  connectView.classList.remove("hidden");
  connectedView.classList.add("hidden");
  document.getElementById("connected-badge").style.display = "none";
  document.getElementById("plan-pill").classList.add("hidden");
  tokenInput.value = "";
  connectBtn.disabled = false;
  connectBtn.textContent = "Connect";
}

function showConnected(token, email, name) {
  connectView.classList.add("hidden");
  connectedView.classList.remove("hidden");

  // Show connected badge in header
  document.getElementById("connected-badge").style.display = "flex";

  // Avatar initial
  const displayName = name || email || "?";
  const initial = displayName.charAt(0).toUpperCase();
  avatarInitial.textContent = initial;

  // Account info
  accountName.textContent = name || email || "Unknown account";
  if (email && name) {
    accountEmail.textContent = email;
  } else {
    accountEmail.textContent = "";
  }

  const short = token.length > 16
    ? token.slice(0, 8) + "…" + token.slice(-6)
    : token;
  accountToken.textContent = short;

  // Fetch plan + usage + refresh user info
  fetch(`${API_BASE}/api/tray/proxy/usage`, {
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((r) => r.ok ? r.json() : null)
    .then((stats) => { if (stats) updatePlanUI(stats); })
    .catch(() => {});

  // Refresh name/email in background (in case storage was stale)
  fetch(`${API_BASE}/api/tray/me`, {
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((r) => r.ok ? r.json() : null)
    .then((me) => {
      if (!me) return;
      if (me.name) {
        accountName.textContent = me.name;
        avatarInitial.textContent = me.name.charAt(0).toUpperCase();
        chrome.storage.local.set({ reattend_name: me.name });
      }
      if (me.email) {
        if (me.name) accountEmail.textContent = me.email;
        else accountName.textContent = me.email;
        chrome.storage.local.set({ reattend_email: me.email });
      }
    })
    .catch(() => {});

}

function updatePlanUI(stats) {
  const planPill = document.getElementById("plan-pill");
  const usageCard = document.getElementById("usage-card");
  const usageFill = document.getElementById("usage-bar-fill");
  const usageCount = document.getElementById("usage-count");
  const meetingsFill = document.getElementById("usage-meetings-fill");
  const meetingsCount = document.getElementById("usage-meetings-count");

  if (stats.plan === "pro") {
    planPill.textContent = "Pro";
    planPill.className = "plan-pill pro";
    planPill.classList.remove("hidden");
    if (usageCard) usageCard.classList.add("hidden");
  } else {
    planPill.textContent = "Free";
    planPill.className = "plan-pill free";
    planPill.classList.remove("hidden");

    const used = stats.aiQueriesUsedToday || 0;
    const limit = stats.aiQueriesLimit || 10;
    const pct = Math.min(100, (used / limit) * 100);
    if (usageFill) usageFill.style.width = pct + "%";
    if (usageCount) usageCount.textContent = `${used} / ${limit}`;

    const mUsed = stats.meetingRecordingsToday || 0;
    const mLimit = stats.meetingRecordingsLimit || 2;
    const mPct = Math.min(100, (mUsed / mLimit) * 100);
    if (meetingsFill) meetingsFill.style.width = mPct + "%";
    if (meetingsCount) meetingsCount.textContent = `${mUsed} / ${mLimit}`;

    if (usageCard) usageCard.classList.remove("hidden");
  }
}

function showError(msg) {
  errorEl.textContent = msg;
  errorEl.classList.remove("hidden");
}
