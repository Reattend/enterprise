const API_BASE = "https://reattend.com";

// ── Context menu: "Save to Reattend" ──────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "save-to-reattend",
    title: "Save to Reattend",
    contexts: ["selection"],
  });

  // Enable side panel
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "save-to-reattend") return;

  const text = info.selectionText;
  if (!text || text.trim().length < 3) return;

  const token = await getToken();
  if (!token) {
    chrome.action.openPopup();
    return;
  }

  const metadata = {
    capture_type: "selection",
    force_save: true,
    source_url: tab?.url || "",
    source_title: tab?.title || "",
  };

  const result = await saveToReattend(token, text.trim(), "extension", metadata);

  if (result.ok) {
    chrome.action.setBadgeText({ text: "✓", tabId: tab?.id });
    chrome.action.setBadgeBackgroundColor({ color: "#6366f1" });
    setTimeout(() => chrome.action.setBadgeText({ text: "", tabId: tab?.id }), 2000);
  } else {
    chrome.action.setBadgeText({ text: "!", tabId: tab?.id });
    chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
    setTimeout(() => chrome.action.setBadgeText({ text: "", tabId: tab?.id }), 3000);
  }
});

// ── Passive capture: smart page tracking ──────────────────────────────

const tabTimers = new Map();
const MIN_TIME_SECONDS = 30;
const CAPTURE_COOLDOWN_MS = 5 * 60 * 1000;
const recentDomains = new Map();

// Domains to SKIP entirely (social media, entertainment — not work)
const SKIP_DOMAINS = [
  "twitter.com", "x.com", "facebook.com", "instagram.com",
  "youtube.com", "reddit.com", "tiktok.com", "pinterest.com",
  "netflix.com", "spotify.com", "twitch.tv",
];

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  flushPreviousTab();
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && isCapturableUrl(tab.url)) {
      tabTimers.set(activeInfo.tabId, {
        url: tab.url,
        title: tab.title || "",
        startTime: Date.now(),
      });
    }
  } catch {}
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.active && tab.url) {
    flushPreviousTab();
    if (isCapturableUrl(tab.url)) {
      tabTimers.set(tabId, {
        url: tab.url,
        title: tab.title || "",
        startTime: Date.now(),
      });
    }
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  const entry = tabTimers.get(tabId);
  if (entry) {
    maybeCapturePageVisit(entry);
    tabTimers.delete(tabId);
  }
});

function flushPreviousTab() {
  for (const [tabId, entry] of tabTimers.entries()) {
    maybeCapturePageVisit(entry);
    tabTimers.delete(tabId);
  }
}

async function maybeCapturePageVisit(entry) {
  const elapsed = (Date.now() - entry.startTime) / 1000;
  if (elapsed < MIN_TIME_SECONDS) return;

  const domain = getDomain(entry.url);

  // Skip social/entertainment domains
  if (SKIP_DOMAINS.some(d => domain === d || domain.endsWith("." + d))) return;

  // Try content extraction first (works on any site with content.js injected)
  await tryContentCapture(entry, elapsed);
}

// Try to extract content from any page via content script.
// Falls back to title + URL if content extraction fails or returns empty.
async function tryContentCapture(entry, elapsed) {
  const domain = getDomain(entry.url);
  const cacheKey = domain + entry.url;
  const lastCapture = recentDomains.get(cacheKey);
  if (lastCapture && Date.now() - lastCapture < CAPTURE_COOLDOWN_MS) return;

  const token = await getToken();
  if (!token) return;

  let text = "";
  let captureType = "page_visit";
  let sourceApp = "Web";

  // Try content extraction via content script
  try {
    const tabs = await chrome.tabs.query({ url: entry.url });
    if (tabs.length > 0) {
      const response = await chrome.tabs.sendMessage(tabs[0].id, { type: "extract_content" });
      if (response?.content && response.content.trim().length > 30) {
        text = response.content.trim();
        captureType = "app_content";
        sourceApp = response.app || domain;
      }
    }
  } catch {
    // Content script not available — use fallback
  }

  // Fallback: title + URL (still useful for Rabbit to know what user was looking at)
  if (!text && entry.title && entry.title.length > 10) {
    text = `Visited: ${entry.title}\n${entry.url}\nTime spent: ${Math.round(elapsed)} seconds`;
  }

  if (!text) return;

  const metadata = {
    capture_type: captureType,
    source_url: entry.url,
    source_title: entry.title,
    source_app: sourceApp,
    time_spent_seconds: Math.round(elapsed),
    domain,
  };

  const result = await saveToReattend(token, text, "extension", metadata);
  if (result.ok) {
    recentDomains.set(cacheKey, Date.now());
    pruneRecentDomains();
  }
}


// ── Helpers ────────────────────────────────────────────────────────────

function isCapturableUrl(url) {
  if (!url) return false;
  if (url.startsWith("chrome://") || url.startsWith("chrome-extension://")) return false;
  if (url.startsWith("about:") || url.startsWith("edge://")) return false;
  if (url === "https://www.google.com/" || url === "https://google.com/") return false;
  const skip = ["newtab", "blank", "devtools"];
  if (skip.some((s) => url.includes(s))) return false;
  return url.startsWith("http://") || url.startsWith("https://");
}

function getDomain(url) {
  try { return new URL(url).hostname; } catch { return url; }
}

function pruneRecentDomains() {
  if (recentDomains.size > 200) {
    const cutoff = Date.now() - CAPTURE_COOLDOWN_MS * 2;
    for (const [d, t] of recentDomains) {
      if (t < cutoff) recentDomains.delete(d);
    }
  }
}

async function getToken() {
  const result = await chrome.storage.local.get("reattend_token");
  return result.reattend_token || null;
}

async function saveToReattend(token, text, source, metadata) {
  try {
    const res = await fetch(`${API_BASE}/api/tray/capture`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ text, source, metadata }),
    });

    if (res.status === 401) {
      await chrome.storage.local.remove("reattend_token");
      return { ok: false, error: "Token expired" };
    }

    const data = await res.json();
    return { ok: res.ok, ...data };
  } catch (err) {
    console.error("[Reattend] Capture failed:", err);
    return { ok: false, error: err.message };
  }
}

// ── Message handler ───────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "offscreen_log") {
    console.log("[Reattend OFFSCREEN]", msg.msg);
    return false;
  }
  if (msg.type === "save_token") {
    chrome.storage.local.set({ reattend_token: msg.token }).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === "get_token") {
    getToken().then((token) => sendResponse({ token }));
    return true;
  }
  if (msg.type === "clear_token") {
    chrome.storage.local.remove("reattend_token").then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === "open_sidepanel") {
    chrome.windows.getCurrent((win) => {
      chrome.sidePanel.open({ windowId: win.id });
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg.type === "search_memories") {
    searchMemories(msg.query).then((results) => sendResponse(results));
    return true;
  }
  if (msg.type === "ask_memory") {
    askMemory(msg.question).then((answer) => sendResponse(answer));
    return true;
  }
  if (msg.type === "get_recent_memories") {
    getRecentMemories().then((memories) => sendResponse(memories));
    return true;
  }

});

// ── API calls for sidebar ─────────────────────────────────────────────

async function searchMemories(query) {
  const token = await getToken();
  if (!token) return { ok: false, error: "Not connected" };
  try {
    const res = await fetch(`${API_BASE}/api/tray/search?q=${encodeURIComponent(query)}&limit=10`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return { ok: false, error: "Search failed" };
    const data = await res.json();
    return { ok: true, results: data.results || data };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function askMemory(question) {
  const token = await getToken();
  if (!token) return { ok: false, error: "Not connected" };
  try {
    const res = await fetch(`${API_BASE}/api/tray/ask`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ question }),
    });
    if (res.status === 429) {
      try {
        const data = await res.json();
        return { ok: false, error: "quota_exceeded", used: data.used, limit: data.limit };
      } catch {
        return { ok: false, error: "quota_exceeded", used: 0, limit: 10 };
      }
    }
    if (!res.ok) return { ok: false, error: "Ask failed" };
    // Response is streaming text/plain, not JSON
    const text = await res.text();
    return { ok: true, answer: text };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function getRecentMemories() {
  const token = await getToken();
  if (!token) return { ok: false, error: "Not connected" };
  try {
    const res = await fetch(`${API_BASE}/api/tray/recent?limit=10`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return { ok: false, error: "Fetch failed" };
    const data = await res.json();
    return { ok: true, records: data.results || [] };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}
